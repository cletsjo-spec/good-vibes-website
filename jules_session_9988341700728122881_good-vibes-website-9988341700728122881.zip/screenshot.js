const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });
  await page.goto('https://docs.google.com/presentation/d/1K8EEFDRfNEwhLgD3pui-vUQ1VGNPWoXIUynqMwgyKdg/edit?usp=sharing', {waitUntil: 'networkidle2'});
  await new Promise(r => setTimeout(r, 10000)); // wait 10s for the slide to load
  await page.screenshot({path: 'screenshot.png'});
  await browser.close();
})();
