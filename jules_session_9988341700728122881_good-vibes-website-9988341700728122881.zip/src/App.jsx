import React from 'react';
import Hero from './components/Hero';
import Problem from './components/Problem';
import Solution from './components/Solution';
import Market from './components/Market';
import BusinessModel from './components/BusinessModel';
import GoToMarket from './components/GoToMarket';
import Team from './components/Team';
import WhyNow from './components/WhyNow';
import Investment from './components/Investment';
import Contact from './components/Contact';

function App() {
  return (
    <div className="font-sans text-gray-900 bg-white">
      <Hero />
      <Problem />
      <Solution />
      <Market />
      <BusinessModel />
      <GoToMarket />
      <Team />
      <WhyNow />
      <Investment />
      <Contact />
    </div>
  );
}

export default App;
