import React from 'react';

const Investment = () => {
  return (
    <section className="py-20 px-8 bg-gray-50 text-gray-900">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Investeringen</h2>
        <h3 className="text-4xl font-bold mb-12">Vi söker vår seed-runda</h3>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-200">
            <div className="text-center mb-8">
              <div className="text-4xl font-extrabold text-indigo-600 mb-2">1,5 – 2 MSEK</div>
              <p className="text-gray-500 uppercase tracking-wide text-sm font-bold">Seed-investering</p>
            </div>
            
            <h4 className="font-bold text-lg mb-4 text-gray-800 border-b pb-2">Pengarna används till:</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2"><span className="text-indigo-500">💰</span> Löner: Erik + Carro (12 mån runway)</li>
              <li className="flex items-center gap-2"><span className="text-indigo-500">🚀</span> Pilot: 2-3 kurser Q1-Q2</li>
              <li className="flex items-center gap-2"><span className="text-indigo-500">📚</span> Kursmaterial & pedagogik</li>
              <li className="flex items-center gap-2"><span className="text-indigo-500">📣</span> Marketing, CAC & plattform (MVP)</li>
            </ul>
          </div>
          
          <div className="bg-indigo-900 text-white p-8 rounded-2xl shadow-sm">
            <h4 className="font-bold text-xl mb-6 text-lime-400 border-b border-indigo-700 pb-2">Milstolpar med din investering:</h4>
            <ul className="space-y-6">
              <li className="flex items-start gap-4">
                <div className="bg-indigo-800 rounded-lg px-3 py-1 text-sm font-bold text-indigo-300 mt-1">Q1 2026</div>
                <div>10+ kurser/mån</div>
              </li>
              <li className="flex items-start gap-4">
                <div className="bg-indigo-800 rounded-lg px-3 py-1 text-sm font-bold text-indigo-300 mt-1">Q3 2026</div>
                <div>Pilot klar</div>
              </li>
              <li className="flex items-start gap-4">
                <div className="bg-indigo-800 rounded-lg px-3 py-1 text-sm font-bold text-indigo-300 mt-1">Q4 2026</div>
                <div>Break-even på kurs</div>
              </li>
              <li className="flex items-start gap-4">
                <div className="bg-indigo-800 rounded-lg px-3 py-1 text-sm font-bold text-indigo-300 mt-1">Q4 2027</div>
                <div className="text-lime-300 font-semibold">Positivt kassaflöde</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Investment;
