import React from 'react';

const Team = () => {
  return (
    <section className="py-20 px-8 bg-indigo-950 text-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-sm font-bold text-indigo-300 uppercase tracking-wider mb-2">Teamet</h2>
        <h3 className="text-4xl font-bold mb-12 text-lime-400">Rätt personer för att göra detta</h3>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-indigo-900/40 p-8 rounded-2xl border border-indigo-800">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-indigo-500 flex items-center justify-center text-2xl font-bold">EB</div>
              <div>
                <h4 className="text-2xl font-bold">Erik Bernsten</h4>
                <p className="text-indigo-300">Co-founder & CCO</p>
              </div>
            </div>
            <ul className="space-y-3 text-indigo-100">
              <li className="flex gap-2"><span>•</span> VP/CCO-nivå – Nextory, Holmen, Michelin</li>
              <li className="flex gap-2"><span>•</span> EF Education First – djup edtech-erfarenhet</li>
              <li className="flex gap-2"><span>•</span> SSE, HEC Paris, INSEAD</li>
              <li className="flex gap-2"><span>•</span> 5 språk, internationell kommersiell ledare</li>
            </ul>
          </div>

          <div className="bg-indigo-900/40 p-8 rounded-2xl border border-indigo-800">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-purple-500 flex items-center justify-center text-2xl font-bold">CL</div>
              <div>
                <h4 className="text-2xl font-bold">Caroline Letsjö</h4>
                <p className="text-purple-300">Co-founder & CMO</p>
              </div>
            </div>
            <ul className="space-y-3 text-indigo-100">
              <li className="flex gap-2"><span>•</span> Expert marknadsföring</li>
              <li className="flex gap-2"><span>•</span> Passion för barn & utbildning</li>
              <li className="flex gap-2"><span>•</span> Förstår målgruppen som förälder</li>
              <li className="flex gap-2"><span>•</span> Kursutveckling & pedagogik</li>
              <li className="flex gap-2"><span>•</span> Ordförande Reedz, Co-founder SmartLitt</li>
              <li className="flex gap-2"><span>•</span> Stark operativ & produktprofil</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Team;
