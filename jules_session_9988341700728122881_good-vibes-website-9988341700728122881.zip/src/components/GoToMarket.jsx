import React from 'react';

const GoToMarket = () => {
  return (
    <section className="py-20 px-8 bg-gray-50 text-gray-900">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Go-to-market</h2>
        <h3 className="text-4xl font-bold mb-12">Tre faser mot skalbar tillväxt</h3>
        
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100">
            <div className="bg-red-500 text-white font-bold p-4 text-center">Fas 1 · År 1</div>
            <div className="p-6">
              <h4 className="text-xl font-bold mb-4 text-center">Piloten</h4>
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-center gap-2"><span className="text-red-500">•</span> 2-3 kurser i Stockholm</li>
                <li className="flex items-center gap-2"><span className="text-red-500">•</span> Validera betalningsvilja</li>
                <li className="flex items-center gap-2"><span className="text-red-500">•</span> Bygga case studies & testimonials</li>
              </ul>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100">
            <div className="bg-indigo-600 text-white font-bold p-4 text-center">Fas 2 · År 2</div>
            <div className="p-6">
              <h4 className="text-xl font-bold mb-4 text-center">Skalning</h4>
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-center gap-2"><span className="text-indigo-600">•</span> 10+ kurser / mån i 3 städer</li>
                <li className="flex items-center gap-2"><span className="text-indigo-600">•</span> Franchise-modell för kursledare</li>
                <li className="flex items-center gap-2"><span className="text-indigo-600">•</span> Sälja in CSR-sponsring</li>
                <li className="flex items-center gap-2"><span className="text-indigo-600">•</span> Rekrytera 2 kursledare</li>
              </ul>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100">
            <div className="bg-teal-500 text-white font-bold p-4 text-center">Fas 3 · År 3+</div>
            <div className="p-6">
              <h4 className="text-xl font-bold mb-4 text-center">Plattform</h4>
              <ul className="space-y-3 text-sm text-gray-600">
                <li className="flex items-center gap-2"><span className="text-teal-500">•</span> Nordisk expansion</li>
                <li className="flex items-center gap-2"><span className="text-teal-500">•</span> Subscription-plattform</li>
                <li className="flex items-center gap-2"><span className="text-teal-500">•</span> Tech-bolag som partners</li>
                <li className="flex items-center gap-2"><span className="text-teal-500">•</span> Lansera online-community</li>
                <li className="flex items-center gap-2"><span className="text-teal-500">•</span> Inkubatorprogram</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GoToMarket;
