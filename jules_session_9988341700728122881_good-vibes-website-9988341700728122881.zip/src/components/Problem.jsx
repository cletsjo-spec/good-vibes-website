import React from 'react';

const Problem = () => {
  return (
    <section className="py-20 px-8 bg-white text-gray-900">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Problemet</h2>
        <h3 className="text-4xl font-bold mb-12">En värld som förändras snabbare än skolan hänger med</h3>
        
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-red-50 p-6 rounded-xl border border-red-100">
            <div className="text-red-500 mb-4">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h4 className="font-bold text-xl mb-2">Barnet oroar sig</h4>
            <p className="text-gray-700 italic">"Vad ska jag bli när AI tar jobben?"</p>
            <p className="text-gray-600 mt-2 text-sm">Brist på självförtroende och framtidstro.</p>
          </div>
          
          <div className="bg-red-50 p-6 rounded-xl border border-red-100">
            <div className="text-red-500 mb-4">
               <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h4 className="font-bold text-xl mb-2">Föräldern oroar sig</h4>
            <p className="text-gray-700 italic">Hur framtidssäkrar jag mitt barn i en automatiserad värld?</p>
            <p className="text-gray-600 mt-2 text-sm">Skolan räcker inte.</p>
          </div>

          <div className="bg-red-50 p-6 rounded-xl border border-red-100">
             <div className="text-red-500 mb-4">
               <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path d="M12 14l9-5-9-5-9 5 9 5z" />
                <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" />
              </svg>
            </div>
            <h4 className="font-bold text-xl mb-2">Studenten oroar sig</h4>
            <p className="text-gray-700 italic">Jag - som går på högskolan och som snart ska ut i arbetslivet - är orolig för att inte få jobb efter examen.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Problem;
