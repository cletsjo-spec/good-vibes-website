import React from 'react';

const Hero = () => {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center text-center p-8 bg-gradient-to-br from-indigo-900 to-purple-900 text-white">
      <h1 className="text-6xl font-extrabold mb-4 tracking-tight">Good Vibes</h1>
      <h2 className="text-3xl font-semibold text-lime-400 mb-6 italic">Vi framtidssäkrar nästa generation</h2>
      <p className="text-xl max-w-2xl text-gray-200">
        Entreprenörskap & AI-kompetens för barn 11-16 år
      </p>
      <div className="mt-12 text-sm text-gray-400">
        Erik Bernsten & Caroline Letsjö • 2026
      </div>
    </section>
  );
};

export default Hero;
