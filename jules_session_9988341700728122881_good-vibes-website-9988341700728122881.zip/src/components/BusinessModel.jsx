import React from 'react';

const BusinessModel = () => {
  return (
    <section className="py-20 px-8 bg-white text-gray-900">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Affärsmodell</h2>
        <h3 className="text-4xl font-bold mb-12">Enkelt, skalbart, lönsamt</h3>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h4 className="font-bold text-xl mb-6 text-indigo-900 border-b pb-2">Intäkter per kurs</h4>
            <ul className="space-y-4">
              <li className="flex justify-between items-center text-gray-700">
                <span>Kursavgift (15 deltagare × 3 000 kr)</span>
                <span className="font-semibold text-green-600">45 000 kr</span>
              </li>
              <li className="flex justify-between items-center text-gray-700">
                <span>Kostnad kursledare + assistent</span>
                <span className="font-semibold text-red-500">−24 000 kr</span>
              </li>
              <li className="flex justify-between items-center text-gray-700">
                <span>Lunch & fika</span>
                <span className="font-semibold text-red-500">−8 500 kr</span>
              </li>
              <li className="flex justify-between items-center text-gray-700">
                <span>Lokal (sponsrad / tbd)</span>
                <span className="font-semibold text-gray-400">0 kr</span>
              </li>
              <li className="flex justify-between items-center pt-4 border-t border-gray-200 font-bold text-lg">
                <span>Bruttomarginal per kurs</span>
                <span className="bg-indigo-100 text-indigo-800 px-4 py-2 rounded-lg">12 500 kr</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-xl mb-6 text-indigo-900 border-b pb-2">Vägen till lönsamhet</h4>
            <ul className="space-y-4">
              <li className="flex gap-3">
                <span className="text-lime-500">✅</span>
                <span className="text-gray-700">132 kurser = full kostnadstäckning</span>
              </li>
              <li className="flex gap-3">
                <span className="text-lime-500">📈</span>
                <span className="text-gray-700">Skalning via timanställda kursledare i nya städer</span>
              </li>
              <li className="flex gap-3">
                <span className="text-lime-500">🌐</span>
                <span className="text-gray-700">Online-kurser & community öppnar för nordisk expansion</span>
              </li>
              <li className="flex gap-3">
                <span className="text-lime-500">🤝</span>
                <span className="text-gray-700">Potentiellt: CSR-sponsring från bolag som varslar personal</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessModel;
