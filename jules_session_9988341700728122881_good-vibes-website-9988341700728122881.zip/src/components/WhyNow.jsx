import React from 'react';

const WhyNow = () => {
  return (
    <section className="py-20 px-8 bg-white text-gray-900">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Varför nu?</h2>
        <h3 className="text-4xl font-bold mb-12">Tailwinds som driver efterfrågan</h3>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
            <h4 className="font-bold text-xl mb-3 text-indigo-900">AI-ångesten är reell</h4>
            <p className="text-gray-700">68% av svenska föräldrar oroar sig för att AI ska ersätta deras barns framtida jobb. <span className="text-sm text-gray-500">(PwC 2024)</span></p>
          </div>
          
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
            <h4 className="font-bold text-xl mb-3 text-indigo-900">Skolan halkar efter</h4>
            <p className="text-gray-700">Läroplanen uppdateras vart 10:e år. AI förändrar arbetsmarknaden vart 2:a år. Gapet ökar.</p>
          </div>

          <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
            <h4 className="font-bold text-xl mb-3 text-indigo-900">Edtech-marknaden exploderar</h4>
            <p className="text-gray-700">Global edtech-marknad: $254Md 2024 → $605Md 2027. K-12 entrepreneurship: snabbast växande segment.</p>
          </div>

          <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
            <h4 className="font-bold text-xl mb-3 text-indigo-900">CSR-budgetar söker hem</h4>
            <p className="text-gray-700">Bolag som varslar i AI-omstrukturering behöver trovärdiga ungdomssatsningar för PR och legitimitet.</p>
          </div>
          
          <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
            <h4 className="font-bold text-xl mb-3 text-indigo-900">Bevisad modell globalt</h4>
            <p className="text-gray-700">Liknande bolag: iD Tech (USA) värderat till $500M+. Digi-Youth (UK), Code.org. Ingen tydlig nordisk ledare.</p>
          </div>

          <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-200">
            <h4 className="font-bold text-xl mb-3 text-indigo-900">Grundarna är redo nu</h4>
            <p className="text-indigo-800 font-medium">Eriks kommersiella erfarenhet + Carros tech-bakgrund + båda föräldrar = rätt team, rätt timing.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyNow;
