import React from 'react';

const Solution = () => {
  return (
    <section className="py-20 px-8 bg-indigo-950 text-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-sm font-bold text-indigo-300 uppercase tracking-wider mb-2">Lösningen</h2>
        <h3 className="text-4xl font-bold mb-6 text-lime-400">Good Vibes</h3>
        <p className="text-xl mb-12 text-indigo-100">
          Intensivkurser där barn 11-16 år lär sig starta egna företag och använda AI —<br/>
          och går hem med något de kan berätta om.
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-indigo-900/50 p-6 rounded-xl border border-indigo-800">
            <div className="text-lime-400 mb-4 text-2xl">🗓️</div>
            <p className="font-medium">5-dagars intensivkurser fysiskt i storstäderna</p>
          </div>
          <div className="bg-indigo-900/50 p-6 rounded-xl border border-indigo-800">
            <div className="text-lime-400 mb-4 text-2xl">🤖</div>
            <p className="font-medium">AI-verktyg & entreprenörskap i praktiken</p>
          </div>
          <div className="bg-indigo-900/50 p-6 rounded-xl border border-indigo-800">
            <div className="text-lime-400 mb-4 text-2xl">🚀</div>
            <p className="font-medium">Barnet bygger något riktigt och lär sig pitcha det</p>
          </div>
          <div className="bg-indigo-900/50 p-6 rounded-xl border border-indigo-800">
            <div className="text-lime-400 mb-4 text-2xl">❤️</div>
            <p className="font-medium">Trygghet & självförtroende — en win tidigt i livet</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Solution;
