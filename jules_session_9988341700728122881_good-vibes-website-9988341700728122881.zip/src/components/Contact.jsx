import React from 'react';

const Contact = () => {
  return (
    <section className="py-24 px-8 bg-gradient-to-br from-indigo-950 to-purple-950 text-center text-white">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-3xl md:text-5xl font-extrabold mb-8 leading-tight">
          Vi garanterar att nästa generation<br/>
          <span className="text-lime-400">har något coolt att berätta om.</span>
        </h2>
        
        <div className="text-2xl font-bold mb-12">Good Vibes.</div>
        
        <div className="bg-indigo-900/40 p-8 rounded-2xl border border-indigo-800 inline-block text-left">
          <div className="mb-6">
            <h3 className="font-bold text-xl">Erik Bernsten</h3>
            <p className="text-indigo-300">erik@goodvibes.se | +46 70 XXX XX XX</p>
          </div>
          <div>
            <h3 className="font-bold text-xl">Caroline Letsjö</h3>
            <p className="text-indigo-300">caroline@goodvibes.se</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
