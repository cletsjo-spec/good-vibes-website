import React from 'react';

const Market = () => {
  return (
    <section className="py-20 px-8 bg-gray-50 text-gray-900">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Marknaden</h2>
        <h3 className="text-4xl font-bold mb-12">Sverige — och sedan vidare</h3>
        
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center">
            <div className="text-5xl font-extrabold text-indigo-600 mb-2">~250k</div>
            <p className="text-gray-600 font-medium">Barn 11-16 år i storstadsregionerna</p>
          </div>
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 text-center">
            <div className="text-5xl font-extrabold text-lime-600 mb-2">~75k</div>
            <p className="text-gray-600 font-medium">I höginkomstfamiljer</p>
            <p className="text-sm text-gray-400">(30% av målgruppen)</p>
          </div>
        </div>

        <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100">
          <h4 className="font-bold text-indigo-900 mb-4">Hur vi räknar:</h4>
          <ul className="space-y-3 text-indigo-800">
            <li className="flex justify-between items-center border-b border-indigo-200 pb-2">
              <span>Barn i Stockholm, Göteborg, Malmö (11-16 år)</span>
              <span className="font-semibold">250 000</span>
            </li>
            <li className="flex justify-between items-center border-b border-indigo-200 pb-2">
              <span>Höginkomsthushåll (30%)</span>
              <span className="font-semibold">75 000</span>
            </li>
            <li className="flex justify-between items-center pt-2 text-indigo-900 font-bold">
              <span>Betalande år 1 (konservativt 0,1%)</span>
              <span className="bg-indigo-200 px-3 py-1 rounded-full">75 barn</span>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
};

export default Market;
