const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });
  await page.goto('http://localhost:5173', {waitUntil: 'networkidle2'});
  
  // scroll down more
  await page.evaluate(() => {
    window.scrollTo(0, window.innerHeight * 2);
  });
  await new Promise(r => setTimeout(r, 500));
  await page.screenshot({path: 'screenshot_local_bot.png'});
  
  await browser.close();
})();
